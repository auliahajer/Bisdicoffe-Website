<?php
$data = json_decode(file_get_contents('php://input'), true);
$productName = $data['productName'];
$productPrice = $data['productPrice'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bisdicoffe";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO cart_items (product_name, product_price) VALUES ('$productName', '$productPrice')";
if ($conn->query($sql) === TRUE) {
  echo json_encode(["message" => "Item added to cart successfully"]);
} else {
  echo json_encode(["message" => "Failed to add item to cart"]);
}

$conn->close();
?>
