<?php
$data = json_decode(file_get_contents('php://input'), true);
$cartItems = $data['cartItems'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bisdicoffe";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$totalAmount = 0;
foreach ($cartItems as $item) {
  $totalAmount += $item['productPrice'];
}

$sql = "INSERT INTO orders (total_amount) VALUES ($totalAmount)";
if ($conn->query($sql) === TRUE) {
  $orderId = $conn->insert_id;
  foreach ($cartItems as $item) {
    $productName = $item['productName'];
    $productPrice = $item['productPrice'];
    $sql = "INSERT INTO order_items (order_id, product_name, product_price) VALUES ($orderId, '$productName', $productPrice)";
    $conn->query($sql);
  }

  $conn->query("DELETE FROM cart_items");

  echo json_encode([
    "message" => "Checkout successful",
    "order" => [
      "id" => $orderId,
      "total_amount" => $totalAmount,
      "items" => $cartItems
    ]
  ]);
} else {
  echo json_encode(["message" => "Checkout failed"]);
}

$conn->close();
?>
